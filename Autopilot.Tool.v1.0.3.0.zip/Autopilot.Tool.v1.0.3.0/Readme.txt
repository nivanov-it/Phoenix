1.
Powershell

2.
Install-Module MSAL.PS -force

3.
slui.exe /upk

4.
changepk.exe /ProductKey VK7JG-NPHTM-C97JM-9MPGT-3V66T